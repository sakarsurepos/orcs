/*****************************************************
This program was produced by the
CodeWizardAVR V1.25.5 Professional
Automatic Program Generator
� Copyright 1998-2007 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 13.5.2008
Author  : Tomi                            
Company : F4CG                            
Comments: 


Chip type           : ATmega128L
Program type        : Application
Clock frequency     : 7,372800 MHz
Memory model        : Small
External SRAM size  : 0
Data Stack size     : 1024
*****************************************************/

#include <mega128.h>

#include <delay.h>

#define FIRST_ADC_INPUT 0
#define LAST_ADC_INPUT 4
unsigned char adc_data[LAST_ADC_INPUT-FIRST_ADC_INPUT+1];
#define ADC_VREF_TYPE 0x20
#define ZAPORNE_NAPATIE PORTA.2
#define NABIJANIE PORTA.3
#define ZDROJ PORTA.6
#define GENERATOR TCCR0
#define NAPATIE_PANELU adc_data[1]
#define NAPATIE_ZDROJA adc_data[3]
#define TEPLOTA_AKUMULATORA adc_data[4]
#define NABIJACI_PRUD adc_data[2]
#define NAPATIE_AKU adc_data[0]
// ADC interrupt service routine
// with auto input scanning
interrupt [ADC_INT] void adc_isr(void)
{
register static unsigned char input_index=0;
// Read the 8 most significant bits
// of the AD conversion result
adc_data[input_index]=ADCH;
// Select next ADC input
if (++input_index > (LAST_ADC_INPUT-FIRST_ADC_INPUT))
   input_index=0;
ADMUX=(FIRST_ADC_INPUT | (ADC_VREF_TYPE & 0xff))+input_index;
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=0x40;
}
int delta_u;                                      // Deklaracia premennej rozdielu napatia medzi akumulatorom a solarnym panelom
unsigned char obmedzenie=0;                       // Deklaracia premennej obmedzenie
unsigned char i;                                  // Deklaracia premennej i
unsigned char status=0;                           // Deklaracia premennej status nabijania
bit panel;                                        // Deklaracia premennej panel

/*********************************************************************************************************************************
********************************************* STANDARDNE A UKONCOVACIE NABIJANIE ************************************************/
int STANDARDNE_NABIJANIE()
{
while(2)                                                // Cyklus bez podmienky
        {
        panel=1;                                        // Premenna panel=1, koli vypadkom slnecneho ziarenia a poklesu napatia
        GENERATOR=0x1C;                                 // Zapne generator pulzov na frekvenciu 28.8 KHz
        for(i=0;i<9;i++)                                // Cyklus pre rychle nabijanie a meranie
                {
                delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;  // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u                                        
                if(delta_u>=15 & panel==1)              // Ak je napatie panelu vacsie ako 15V a nevypadlo ziarenie pocas cyklu, tak odpoji zdroj
                ZDROJ=1;                                // Zapne port pre odpojenie zdroja                   
                NABIJANIE=0;                            // Zapne port pre nabijanie
                delay_ms(50);                           // Nabija a caka 50ms
                delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;  // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
                if(delta_u<15)                          // Ak vypadne ziarenie, tak cely cyklus je nahradeny zdrojom
                        {
                        panel=0;                        // panel=0, koli tomu aby sa v tomto cykle uz nenabijalo pomocou Solarneho panelu
                        ZDROJ=0;                        // Pripoji zdroj
                        }
                delay_ms(50);                           // Nabija a caka 50 ms koli stabilzacii zdroja
                if(NAPATIE_ZDROJA<165)                  // Ak je napatie zdroja mensie ako 15V, tak odpoji nabijanie (1)
                break;                                  // Prerusi cyklus (nabijanie) (1)                               
                }
        if(NAPATIE_ZDROJA<165)                          // Ak je napatie zdroja mensie ako 15V, tak odpoji nabijanie (2)
                {
                GENERATOR=0x00;                         // Odpoji generator pulzov
                ZDROJ=0;                                // Pripoji zdroj
                break;                                  // Prerusi cyklus (nabijanie) (2)
                }
        if(NABIJACI_PRUD>=125)                          // Ak je nabijaci prud mensi ako 50mA, tak odpoji nabijanie
                {
                GENERATOR=0x00;                         // Odpoji generator pulzov
                status=1;                               // staus=1, ked je plna kapacita
                break;                                  // Prerusi cyklus (nabijanie)
                }
        if(TEPLOTA_AKUMULATORA>=179)                    // Ak je teplota akumulatora vyssia ako 50C, tak uplne odpoji nabijanie
                {
                GENERATOR=0x00;                         // Odpoji generator pulzov
                status=2;                               // status=2, ked je prekroceny limit teploty
                break;                                  // Prerusi cyklus (nabijanie)
                }
        delay_ms(100);                                  // Caka 100ms
        obmedzenie++;                                   // Pripocita 1 koli obmedzeniu zapornych impulzov na akumulatore
        if(NAPATIE_AKU<165 | obmedzenie>=10)            /* Ak je napatie na akumulatore mensie ako 13.5V, alebo obmedzovaci pocet cyklov
                                                        vacsi alebo rovny 10, tak sa spusti zaporny impulz */
                {
                NABIJANIE=1;                            // Vypne port pre nabijanie
                delay_ms(1);                            // Caka 1ms na stabilizaciu
                ZAPORNE_NAPATIE=1;                      // Zapne port pre zaporne napatie
                delay_us(5);                            // Caka 5us
                ZAPORNE_NAPATIE=0;                      // Vypne port pre zaporne napatie
                delay_ms(1);                            // Caka 1ms na stabilizaciu
                obmedzenie=0;                           // Vynuluje premennu obmedzenie
                }                                      
        }
        return status;
}
/*********************************************************************************************************************************
*************************************************** UDRZIAVACIE NABIJANIE *******************************************************/
int UDRZIAVACIE_NABIJANIE()
{
while(status==1 & (NAPATIE_ZDROJA>=181 | delta_u>=15))  // Ak akumulator ma plnu kapacitu a je pripojeny zdroj, tak prechadza do rezimu udrzovacieho nabijania 
        {
        NABIJANIE=0;                                    // Zapne port pre nabijanie
        delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;       // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u                          
        if(delta_u>=15)                                 // Ak je delta_u vacsie ako 14, tak odpoji zdroj
                ZDROJ=1;                                // Odpoji zdroj
        else                                            // Pokial predchadzajuca podmienka neplati, tak zdroj ostane pripojeny
                ZDROJ=0;                                // Pripoji zdroj
        delay_ms(50);                                   // Caka 50ms
        }
return delta_u;
}
/*********************************************************************************************************************************
**************************************************** ZAKAZANE NABIJANIE *********************************************************/
int ZAKAZANE_NABIJANIE()
{
while(status==2 & (NAPATIE_ZDROJA>=165 | delta_u>=15))  // Ak akumulator prekrocil teplotu 45C, tak nabijanie sa automaticky odpaja
        {
        NABIJANIE=1;                                    // Vypne port pre nabijanie
        delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;       // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u     
        if(delta_u>=15)                                 // Ak je delta_u vacsie ako 14, tak odpoji zdroj
                ZDROJ=1;                                // Odpoji zdroj
        else                                            // Pokial predchadzajuca podmienka neplati, tak zdroj ostane pripojeny
                ZDROJ=0;                                // Pripoji zdroj
        delay_ms(50);                                   // Caka 50ms
        }
return delta_u;        
}
/*********************************************************************************************************************************
***************************************************** POMOCNE NABIJANIE *********************************************************/
void POMOCNE_NABIJANIE()
{
if(delta_u>=15 & NAPATIE_ZDROJA<184)            // Ak je delta_u vacsie ako 14 a nieje pripojeny zdroj, tak pripoji panel ako pomocny zdroj napajania
NABIJANIE=0;                                    // Zapne port pre nabijanie (pre podporu napajania)
else                                            // Pokial predchadzajuca podmienka neplati, tak podpora napajania zostane vypnuta
NABIJANIE=1;                                    // Vypne port pre nabijanie
}

void main(void)
{
// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Func7=In Func6=Out Func5=In Func4=In Func3=Out Func2=Out Func1=In Func0=In 
// State7=T State6=0 State5=T State4=T State3=0 State2=0 State1=T State0=T 
PORTA=0x00;
DDRA=0x4C;

// Port B initialization
// Func7=In Func6=In Func5=In Func4=Out Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=0 State3=T State2=T State1=T State0=T 
PORTB=0x00;
DDRB=0x10;

// Port C initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTC=0x00;
DDRC=0x00;

// Port D initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTD=0x00;
DDRD=0x00;

// Port E initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTE=0x00;
DDRE=0x00;

// Port F initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTF=0x00;
DDRF=0x00;

// Port G initialization
// Func4=In Func3=In Func2=In Func1=In Func0=In 
// State4=T State3=T State2=T State1=T State0=T 
PORTG=0x00;
DDRG=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 28,800 kHz
// Mode: CTC top=OCR0
// OC0 output: Toggle on compare match
ASSR=0x00;
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Normal top=FFFFh
// OC1A output: Discon.
// OC1B output: Discon.
// OC1C output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
// Compare C Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;
OCR1CH=0x00;
OCR1CL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// Timer/Counter 3 initialization
// Clock source: System Clock
// Clock value: Timer 3 Stopped
// Mode: Normal top=FFFFh
// Noise Canceler: Off
// Input Capture on Falling Edge
// OC3A output: Discon.
// OC3B output: Discon.
// OC3C output: Discon.
// Timer 3 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
// Compare C Match Interrupt: Off
TCCR3A=0x00;
TCCR3B=0x00;
TCNT3H=0x00;
TCNT3L=0x00;
ICR3H=0x00;
ICR3L=0x00;
OCR3AH=0x00;
OCR3AL=0x00;
OCR3BH=0x00;
OCR3BL=0x00;
OCR3CH=0x00;
OCR3CL=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
// INT3: Off
// INT4: Off
// INT5: Off
// INT6: Off
// INT7: Off
EICRA=0x00;
EICRB=0x00;
EIMSK=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;
ETIMSK=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 57,600 kHz
// ADC Voltage Reference: AREF pin
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=FIRST_ADC_INPUT | (ADC_VREF_TYPE & 0xff);
ADCSRA=0xCF;

// Global enable interrupts
#asm("sei")

while (1)
      {
      while(NAPATIE_ZDROJA>=184)                // Ak je napatie na zdroji vacsie ako 15V, tak sa zacne cyklus standardneho nabuijania
                                                                        
      {
      STANDARDNE_NABIJANIE();                   // Vola funkciu pre standardne nabijanie
      }
      delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU; // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
      UDRZIAVACIE_NABIJANIE();                  // Vola funkciu pre udrziavacie nabijanie
      ZAKAZANE_NABIJANIE();                     // Vola funkciu pre zakazane nabijanie
      if (status !=0)
        {
        status=0;                               // Ak uplne vyjde nabijanie zo vsetkych cyklov, tak status=0
                                                
        }
      POMOCNE_NABIJANIE();                      // Vola funkciu pre pomocne nabijanie

      };
}
