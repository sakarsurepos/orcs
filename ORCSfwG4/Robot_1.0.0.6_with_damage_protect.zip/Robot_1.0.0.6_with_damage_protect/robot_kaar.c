/*****************************************************
This program was produced by the
CodeWizardAVR V1.24.8d Professional
Automatic Program Generator
� Copyright 1998-2006 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : ROBOT_KAAR
Version : 1.0.0.3
Date    : 6.12.2007
Author  : Stanislav Spisak                            
Company : TUKE SJF KAAR                            
Comments: 


Chip type           : ATmega128L
Program type        : Application
Clock frequency     : 7,372800 MHz
Memory model        : Small
External SRAM size  : 0
Data Stack size     : 1024
*****************************************************/

#include <mega128.h>

#include <stdio.h>
#include <delay.h>
#include <stdlib.h>
#include <string.h>

// Alphanumeric LCD Module functions
#asm
   .equ __lcd_port=0x1B ;PORTA
#endasm
#include <lcd.h>

#define RXB8 1
#define TXB8 0
#define UPE 2
#define OVR 3
#define FE 4
#define UDRE 5
#define RXC 7 

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)

#define CAMERA PORTC.3
#define H_V_CAM_SERVO PORTC.7=PORTC.6
#define FOREWARD PORTD.6
#define BACKWARD PORTD.7
#define SERVOS_PWM 9216  //50 Hz
#define DC_MOTOR_PWM 9216 //50 Hz 
#define DIRECTION_SERVO PORTC.5
#define GPS PORTC.0

//#define FIRST_ADC_INPUT 0
//#define LAST_ADC_INPUT 0 

#define RX_BUFFER_SIZE1 128
#define GPS_BUFFER 128
#define TX_BUFFER_SIZE0 128
#define RX_BUFFER_SIZE0 20
#define DATA_BYTES0 20
   

#define FIRST_ADC_INPUT 0
#define LAST_ADC_INPUT 7
#define ADC_VREF_TYPE 0x20



char tx_buffer0[TX_BUFFER_SIZE0];
char rx_buffer1[RX_BUFFER_SIZE1];
char rx_buffer0[RX_BUFFER_SIZE0];
char GPS_data[GPS_BUFFER];

char data_bytes[DATA_BYTES0];
char data_0[DATA_BYTES0];

unsigned char adc_data[LAST_ADC_INPUT-FIRST_ADC_INPUT+1];

bit rx_buffer_overflow1;
bit rx_buffer_overflow0;       
bit ENABLE_MOVEMENT;


unsigned int GPS_index;
unsigned int Timer_0;
unsigned int status;
unsigned int c_counter;
unsigned int rx_wr_index1,rx_rd_index1,rx_counter1;
unsigned int rx_wr_index0, rx_rd_index0, rx_counter0, counter;
unsigned int tx_rd_index0,tx_counter0,tx_wr_index0;

unsigned char SPEED_DOWN=1;

unsigned char Button_timer=0, TEMP_BUTTON0[3]={1,1,1}, TEMP_BUTTON1[3]={1,1,1}, TEMP_BUTTON2[3]={1,1,1}, BUTTON0=0, BUTTON1=0, BUTTON2=0;
unsigned char LCD_TIMER=0, f;
bit ENABLE_BUTTON, ENTER, ENABLE_ENTER;
char LCD_CHAR[6];
float BATTERY_VOLTAGE;
int BATTERY_CAPACITY, BUTTON_MODE;
 

//************************************************************* ADC ******************************************************************

// ADC interrupt service routine
// with auto input scanning
interrupt [ADC_INT] void adc_isr(void)
{
        static unsigned char input_index=0;
        // Read the 8 most significant bits
        // of the AD conversion result
        adc_data[input_index]=ADCH;
        // Select next ADC input
        if (++input_index > (LAST_ADC_INPUT-FIRST_ADC_INPUT))
           input_index=0;
        ADMUX=(FIRST_ADC_INPUT|ADC_VREF_TYPE)+input_index;
        // Start the AD conversion
        ADCSRA|=0x40;
} 


//**************************************************** RX INTERRUPT USART0 ***********************************************************

// USART0 Receiver interrupt service routine
interrupt [USART0_RXC] void usart0_rx_isr(void)
        {
        char status,data;
        status=UCSR0A;
        data=UDR0;
        if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
                {      
                rx_buffer0[rx_wr_index0]=data;
                if (++rx_wr_index0 == RX_BUFFER_SIZE0) 
                        rx_wr_index0=0;
                if (++rx_counter0 == RX_BUFFER_SIZE0)
                        {
                        rx_counter0=0;
                        rx_buffer_overflow0=1;
                        };               
                };
        }

//**************************************************** TX INTERRUPT USART0 ************************************************************

// USART0 Transmitter interrupt service routine
interrupt [USART0_TXC] void usart0_tx_isr(void)
{
if (tx_counter0)
   {
   --tx_counter0;
   UDR0=tx_buffer0[tx_rd_index0];
   if (++tx_rd_index0 == TX_BUFFER_SIZE0) 
        tx_rd_index0=0;
   };
}

//***************************************************** RD_USART0 *****************************************************************

void RD_USART0(void)
         {
         while(rx_counter0 != 0)
                  {
                  #asm("cli")
                  data_0[counter] = rx_buffer0[rx_rd_index0];
                                          
                  if(data_0[counter - 7] == '$' && data_0[counter - 6] == 'A' && data_0[counter - 5] == '7')
                        { 
                        if(data_0[counter] == 10/*<LF>*/)
                                { 
                                data_bytes[2] = data_0[counter - 4];
                                data_bytes[1] = data_0[counter - 3];
                                data_bytes[0] = data_0[counter - 2];
                                counter = 0;                                
                                goto here1;                                
                                }
                        }
                   counter++;
                   here1:
                   if(++rx_rd_index0 == RX_BUFFER_SIZE0)
                        rx_rd_index0 =0;
                   --rx_counter0;
                  #asm("sei")
                  }
         }

char RD_DATA_BUFFER(int znak)
        {
        return data_bytes[znak];
        }


//************************************************** RX INTERRUPT USART1 *************************************************************
// USART1 Receiver interrupt service routine
interrupt [USART1_RXC] void usart1_rx_isr(void)
{
char status,data;
status = UCSR1A;
data = UDR1;

if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN)) == 0)
   {
   rx_buffer1[rx_wr_index1] = data;
   
   if(++rx_wr_index1 == RX_BUFFER_SIZE1)
          rx_wr_index1=0;
       
   if(++rx_counter1 == RX_BUFFER_SIZE1)
        {
        rx_counter1=0;
        rx_buffer_overflow1=1;
        };
       
   };
} 
//*********************************************************************************************************************************
void WR_USART0(char data_for_send)
{
         while (tx_counter0 == TX_BUFFER_SIZE0);
         #asm("cli")
         if (tx_counter0 || ((UCSR0A & DATA_REGISTER_EMPTY)==0))
                  {
                  tx_buffer0[tx_wr_index0] = data_for_send;
                  if (++tx_wr_index0 == TX_BUFFER_SIZE0) 
                          tx_wr_index0=0;
                  ++tx_counter0;
                  }
         else
                  UDR0=data_for_send;
         #asm("sei")
}

void RD_USART1(void)
        { 
        while(rx_counter1 != 0)
                {
                GPS_data[GPS_index] = rx_buffer1[rx_rd_index1];
                
                #asm("cli")        
                if(GPS_data[GPS_index] == 10)
                        { 
                        for(c_counter = 0;c_counter <= GPS_index; c_counter++)
                                {
                                WR_USART0(GPS_data[c_counter]);                                                                    
                                }
                        GPS_index = 0;
                        goto here;
                        };
                
                GPS_index++;
                here:
                if(++rx_rd_index1 == RX_BUFFER_SIZE1)
                        rx_rd_index1 = 0;
                        
                --rx_counter1;
                #asm("sei")
                };
        }

//**************************************************** DEVICES ****************************************************************
void SERVO1( int servo1 )                       //Direction servo
        {
        OCR3CH = (servo1 >> 8) & 0xFF;
        OCR3CL = servo1 & 0xFF;
        } 
        
void SERVO3( int servo3 )                       //Camera servo
        {
        OCR3AH = (servo3 >> 8) & 0xFF;
        OCR3AL = servo3 & 0xFF;
        } 
        
void SERVO2( int servo2 )
        {
        OCR3BH = (servo2 >> 8) & 0xFF;
        OCR3BL = servo2 & 0xFF;
        }                

void DC_MOTOR ( int dc_motor )
        {
        OCR1BH = (dc_motor >> 8) & 0xFF;
        OCR1BL = dc_motor & 0xFF;
        } 
        
void BATTERY_STATUS(void)
        {
        if(status == 1)
                {
                WR_USART0('$');
                WR_USART0('M');
                WR_USART0('S');
                WR_USART0('G');
                WR_USART0('1');
                WR_USART0(',');
                WR_USART0(adc_data[0]);
                WR_USART0(13);             //<CR>
                WR_USART0(10);             //<LF>
                
                status = 0;
                }
        }               
//**************************************************** TIMER_0 ***************************************************************
//Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
TCNT0=0x01;/*
if(Button_timer<=2)
        {
        if(( PING | 0b11011 ) == 0b11011)
                TEMP_BUTTON0[Button_timer]=1;
        else
                TEMP_BUTTON0[Button_timer]=0;
        if(( PING | 0b11101 ) == 0b11101)
                TEMP_BUTTON1[Button_timer]=1;
        else
                TEMP_BUTTON1[Button_timer]=0;
        if(( PING | 0b11110 ) == 0b11110)
                TEMP_BUTTON2[Button_timer]=1;
        else
                TEMP_BUTTON2[Button_timer]=0;
        }
if(Button_timer==2)
        {
        BUTTON0=(TEMP_BUTTON0[0] | TEMP_BUTTON0[1] | TEMP_BUTTON0[2]);
        BUTTON1=(TEMP_BUTTON1[0] | TEMP_BUTTON1[1] | TEMP_BUTTON1[2]);
        BUTTON2=(TEMP_BUTTON2[0] | TEMP_BUTTON2[1] | TEMP_BUTTON2[2]);
        } 
if(LCD_TIMER==10)
       {
       switch (BUTTON_MODE) 
        {
        case 0:
        lcd_gotoxy(0,0);
        lcd_putsf("Prog1");
        break;
        case 1:
        lcd_gotoxy(0,0);
        lcd_putsf("Prog2");
        break;
        case 2:
        lcd_gotoxy(0,0);
        lcd_putsf("Sett.");
        break;
        case 3:
        if(ENTER==0)
                {
                lcd_gotoxy(0,0);
                lcd_putsf("Info ");
                }
        else
                {
                lcd_gotoxy(0,0);
                lcd_putsf("Voltage:");
                lcd_gotoxy(14,0);
                lcd_putsf("V");
                lcd_gotoxy(9,0);
                BATTERY_VOLTAGE=adc_data[0];
                BATTERY_VOLTAGE=BATTERY_VOLTAGE/9.6;
                ftoa(BATTERY_VOLTAGE,1,LCD_CHAR);
                lcd_puts(LCD_CHAR);
                lcd_gotoxy(0,1);
                lcd_putsf("Capacity:");
                BATTERY_CAPACITY=(adc_data[0]-92)*3.5;
                if(adc_data[0]<92)
                        {
                        lcd_gotoxy(9,1);
                        lcd_putsf("Too low");
                        }
                else
                        {
                        lcd_gotoxy(9,1);
                        lcd_putsf("    ");
                        lcd_gotoxy(9,1);
                        itoa(BATTERY_CAPACITY,LCD_CHAR);
                        lcd_puts(LCD_CHAR);
                        lcd_gotoxy(13,1);
                        lcd_putsf("%  ");
                        }
                }
        break;
        }; 

                                  //
        lcd_gotoxy(0,0);
        lcd_putsf("Voltage:");
        lcd_gotoxy(14,0);
        lcd_putsf("V");
        lcd_gotoxy(9,0);
        BATTERY_VOLTAGE=adc_data[0];
        BATTERY_VOLTAGE=BATTERY_VOLTAGE/9.6;
        ftoa(BATTERY_VOLTAGE,1,LCD_CHAR);
        lcd_puts(LCD_CHAR);
        lcd_gotoxy(0,1);
        lcd_putsf("Capacity:");
        BATTERY_CAPACITY=(adc_data[0]-92)*3.5;
        if(adc_data[0]<92)
                {
                lcd_gotoxy(9,1);
                lcd_putsf("Too low");
                }
        else
                {
                lcd_gotoxy(9,1);
                lcd_putsf("    ");
                lcd_gotoxy(9,1);
                itoa(BATTERY_CAPACITY,LCD_CHAR);
                lcd_puts(LCD_CHAR);
                lcd_gotoxy(13,1);
                lcd_putsf("%  ");
                }                  //
       LCD_TIMER=0;
       }
Button_timer++;
LCD_TIMER++;
if(Button_timer==3)
        Button_timer=0;
*/
Timer_0++; 
if(Timer_0 == 28)
        {
        status = 1;
        Timer_0 = 0;
        }     
} 

//***************************************************** MAIN *****************************************************************

void main(void)
{ 

int servo_start_position = 280;
//int dc_motor_start_position = 0;
int korekcia_1 = 146;
int a;
char data[DATA_BYTES0];

//****************************************** PORT A 
// Input/Output Ports initialization 
// Port A initialization
// Func7=In Func6=Out Func5=In Func4=In Func3=Out Func2=Out Func1=In Func0=In 
PORTA=0x00;
DDRA=0x00;
//****************************************** PORT B
// Port B initialization
// DDRB.0 = 1;  PORTB.0 = 1; SERVO1 - power supply transistor - (normally ON)
// DDRB.6 = PWM OC3A   PORTE.3 = 0
PORTB=0x00;                                                                                 
DDRB=0xF0;
//****************************************** PORT C
//DDRC.7 = 1; PORTC.7 = 1; CAMERA ON/OFF (normally ON)
//DDRC.2, DDRC.4 = 0; OPTICALS SENSORS
PORTC=0xFF;
DDRC=0xFF;
//****************************************** PORT D
// Port D initialization
// DDRD.5 = 1; PORTD.5 = 0; DC_MOTOR_Direction 1/1 (normally OFF)
// DDRD.6 = 1; PORTD.6 = 0; DC_MOTOR_Direction 1/2 (normally OFF)
PORTD=0x00;
DDRD=0xF0;
//****************************************** PORT E
// Port E initialization
// DDRE.3 = PWM OC3A   PORTE.3 = 0; SERVO#2
// DDRE.4 = PWM OC3B   PORTE.4 = 0; SERVO#1
// DDRE.5 = PWM OC3C   PORTE.5 = 0; SERVO#3
// DDRE.6 = 1;  PORTB.6 = 1; SERVO2 - power supply transistor - (normally ON)
// DDRE.7 = 1;  PORTB.7 = 1; SERVO3 - power supply transistor - (normally ON)
PORTE=0x00;
DDRE=0x38;
//****************************************** PORT F
// Port F initialization
PORTF=0x00;
DDRF=0x00;
//****************************************** PORT G
// Port G initialization
PORTG=0x1F;
DDRG=0x00;
//****************************************** TIMER 0
// Timer/Counter 0 initialization
// Clock source: 7200Hz System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=FFh
// OC0 output: Disconnected
ASSR=0x00;
TCCR0=0x07;
TCNT0=0x01;
//TCCR0=0x00;
//TCNT0=0x00;
OCR0=0x00;
//****************************************** TIMER 1
// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 7372,800 kHz
// Mode: Ph. & fr. cor. PWM top=ICR1
// OC1A output: Discon.
// OC1B output: Non-Inv.
// OC1C output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
// Compare C Match Interrupt: Off
TCCR1A=0xA0;
TCCR1B=0x11;
TCNT1H=0x00;
TCNT1L=0x00;

ICR1H =(DC_MOTOR_PWM >> 8) & 0xFF;
ICR1L = DC_MOTOR_PWM & 0xFF;

DC_MOTOR(0);  //DC motor null

//***************************************** TIMER 2 
// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;
//***************************************** TIMER 3 
// Timer/Counter 3 initialization
// Clock source: System Clock
// Clock value: 7372,800 kHz
// Mode: Ph. & fr. cor. PWM top=ICR3
// Noise Canceler: Off
// Input Capture on Falling Edge
// OC3A output: Discon.
// OC3B output: Non-Inv.
// OC3C output: Discon.
// Timer 3 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
// Compare C Match Interrupt: Off
TCCR3A=0xA8;
TCCR3B=0x12;
TCNT3H=0x00;
TCNT3L=0x00;

ICR3H =(SERVOS_PWM >> 8) & 0xFF;
ICR3L = SERVOS_PWM & 0xFF;

SERVO1(640);
SERVO2(640);
SERVO3(625);
//**************************************************

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
// INT3: Off
// INT4: Off
// INT5: Off
// INT6: Off
// INT7: Off
EICRA=0x00;
EICRB=0x00;
EIMSK=0x00;
//**************************************************
// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x01;
ETIMSK=0x00;
//**************************************************
// USART0 initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART0 Receiver: On
// USART0 Transmitter: On
// USART0 Mode: Asynchronous
// USART0 Baud rate: 19200
UCSR0A=0x00;
UCSR0B=0xD8;
UCSR0C=0x06;
UBRR0H=0x00;
UBRR0L=0x17;
//**************************************************
// USART1 initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART1 Receiver: On
// USART1 Transmitter: On
// USART1 Mode: Asynchronous
// USART1 Baud rate: 4800
UCSR1A=0x00;
UCSR1B=0xD8;
UCSR1C=0x06;
UBRR1H=0x00;
UBRR1L=0x5F;
//**************************************************
// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 900,600 kHz
// ADC Voltage Reference: AREF pin
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=FIRST_ADC_INPUT|ADC_VREF_TYPE;
//ADMUX=FIRST_ADC_INPUT | (ADC_VREF_TYPE & 0xff);
//ADCSRA=0xCD;
ADCSRA=0xCF;

//***************************************************


// LCD module initialization
lcd_init(16);

lcd_gotoxy(2,0);
lcd_putsf("ORCS-PCB G4");
lcd_gotoxy(0,1);
lcd_putsf("orcs.sebsoft.com");
delay_ms(4000);
lcd_clear();

// Global enable interrupts
#asm("sei")

while (1)
       {/*
       if(BUTTON1==1 & ENABLE_BUTTON==1)
        {
        if(ENTER==0)
                BUTTON_MODE++;
        if(BUTTON_MODE>3)
                BUTTON_MODE=0;
        ENABLE_BUTTON=0;
        }
       if(BUTTON0==1 & ENABLE_BUTTON==1)
        {
        if(ENTER==0)
                BUTTON_MODE--;
        if(BUTTON_MODE<0)
                BUTTON_MODE=3;
        ENABLE_BUTTON=0;
        }
       if(BUTTON0==0 & BUTTON1==0 & ENABLE_BUTTON==0)
        ENABLE_BUTTON=1;
        
       if(BUTTON2==1 & ENABLE_ENTER==1)
        {
        ENTER=!ENTER;
        ENABLE_ENTER=0;
        }
       else 
       if(BUTTON2==0 & ENABLE_ENTER==0)
        {
        lcd_clear();
        ENABLE_ENTER=1;
        }*/

       RD_USART1();             //Read GPS data from USART1 
       BATTERY_STATUS();        //Send msg "battery status"
       RD_USART0();             //Read incoming msg
       
       data[2] = RD_DATA_BUFFER(2);
       data[1] = RD_DATA_BUFFER(1);
       data[0] = RD_DATA_BUFFER(0);
       if(PINC.5 == 0)
        SPEED_DOWN=3;
       else
        SPEED_DOWN=1;      
       if((PINC.2 | PINC.4)==0)
                {
                FOREWARD = 1;
                BACKWARD = 1;
                DC_MOTOR (63);
                ENABLE_MOVEMENT=0;
                }
       else if(PINC.2==0)
                {
                FOREWARD = 1;
                BACKWARD = 0;
                DC_MOTOR ( 6000 );
                ENABLE_MOVEMENT=0;
                }
       else if(PINC.4==0)
                {
                FOREWARD = 0;
                BACKWARD = 1;
                DC_MOTOR ( 6000 / SPEED_DOWN );
                ENABLE_MOVEMENT=0;
                }
       if ((PINC.2 & PINC.4)==1)
                {
                FOREWARD = 1;
                BACKWARD = 1;
                DC_MOTOR (63); 
                ENABLE_MOVEMENT=1;
                }
       switch(data[2])
                {                                                             
                case 'M':  ///////////////////////////// MOTION //////////////////////////////                                                                                               
                if(data[1] == '!' && ENABLE_MOVEMENT==1)                  // FOREWARD
                        {
                        FOREWARD = 0;
                        BACKWARD = 1;
                        a = (int)data[0];
                        DC_MOTOR ( (korekcia_1 * a) / SPEED_DOWN);
                        } 
                                        
                else if(data[1] == '%' && ENABLE_MOVEMENT==1)              // BACKWARD
                        {
                        FOREWARD = 1;
                        BACKWARD = 0;
                        a = (int)data[0];
                        DC_MOTOR ( korekcia_1 * a );
                        }      
                                        
                else if(data[1] == ')' && ENABLE_MOVEMENT==1)              // STOP
                        {
                        FOREWARD = 1;
                        BACKWARD = 1;
                        DC_MOTOR (63);
                        }
                break;                 
                                   
             case 'D':   ////////////////////////// DIRECTION /////////////////////////////
                 
                if(data[1] == '1')
                        { 
                        DIRECTION_SERVO = 1;                 //Direction Servo#1 enabled
                        }
                else if(data[1] == '0')
                        { 
                        DIRECTION_SERVO = 0;                 //Direction Servo#1 disabled
                        }
                a = (int)data[0];
                SERVO1(servo_start_position + 5*a);
                a = 0;
                                      
                break;           
                                
             case 'G':   /////////////////////////////GPS /////////////////////////////////
                
                if(data[1] == '1')
                        {
                        GPS = 1;                 //enabled
                        }
                else if(data[1] == '0')
                        {
                        GPS = 0;                 //disabled
                        }
                break;
                
             case 'C':   /////////////////////////// CAMERA ///////////////////////////////
                 
                if(data[1] == '1')                   //camera servo#2
                        { 
                        a = (int)data[0];      
                        SERVO2(servo_start_position + 5*a);
                        a = 0;
                        }
                else if(data[1] == '2')              //camera servo#3
                        {                                 
                        a = (int)data[0];      
                        SERVO3(servo_start_position + 5*a);
                        a = 0;            
                        }                       
                else if(data[1] == '3')              
                        { 
                        if(data[0] == '0')
                                H_V_CAM_SERVO = 0;     //servo#2,3 disabled
                        else if(data[0] == '1')
                                H_V_CAM_SERVO = 1;     //servo#2,3 enabled       
                        }   
                else if(data[1] == '5')              
                        { 
                        if(data[0] == '0')
                                CAMERA = 0;     //camera disabled
                        else if(data[0] == '1')
                                CAMERA = 1;     //camera enabled       
                        }
                break; 
            
             default:
                break;
             }
                                                      
        
       };
}
