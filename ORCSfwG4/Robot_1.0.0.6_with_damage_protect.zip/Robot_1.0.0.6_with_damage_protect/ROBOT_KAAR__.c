/*****************************************************
This program was produced by the
CodeWizardAVR V1.24.8d Professional
Automatic Program Generator
� Copyright 1998-2006 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : ROBOT_KAAR
Version : 1.0.0.3
Date    : 6.12.2007
Author  : Stanislav Spisak
Company : TUKE SJF KAAR
Comments:


Chip type           : ATmega128L
Program type        : Application
Clock frequency     : 7,372800 MHz
Memory model        : Small
External SRAM size  : 0
Data Stack size     : 1024
*****************************************************/

#include <mega128.h>
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x20
	.EQU __sm_mask=0x1C
	.EQU __sm_powerdown=0x10
	.EQU __sm_powersave=0x18
	.EQU __sm_standby=0x14
	.EQU __sm_ext_standby=0x1C
	.EQU __sm_adc_noise_red=0x08
	.SET power_ctrl_reg=mcucr
	#endif

#include <stdio.h>
#include <delay.h>

#define RXB8 1
#define TXB8 0
#define UPE 2
#define OVR 3
#define FE 4
#define UDRE 5
#define RXC 7

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)

#define CAMERA PORTC.7
#define H_V_CAM_SERVO PORTE.6
#define FOREWARD PORTD.5
#define BACKWARD PORTD.6
#define SERVOS_PWM 9216  //50 Hz
#define DC_MOTOR_PWM 9216 //50 Hz
#define DIRECTION_SERVO PORTB.0
#define GPS PORTD.1

//#define FIRST_ADC_INPUT 0
//#define LAST_ADC_INPUT 0

#define RX_BUFFER_SIZE1 128
#define GPS_BUFFER 128
#define TX_BUFFER_SIZE0 128
#define RX_BUFFER_SIZE0 20
#define DATA_BYTES0 20


#define FIRST_ADC_INPUT 0
#define LAST_ADC_INPUT 3
#define ADC_VREF_TYPE 0x20
#define ZAPORNE_NAPATIE PORTA.2
#define NABIJANIE PORTA.3
#define ZDROJ PORTA.6
#define GENERATOR TCCR0
#define NAPATIE_PANELU adc_data[1]
#define NAPATIE_ZDROJA adc_data[3]
//#define TEPLOTA_AKUMULATORA adc_data[4]
#define NABIJACI_PRUD adc_data[2]
#define NAPATIE_AKU adc_data[0]



char tx_buffer0[TX_BUFFER_SIZE0];
char rx_buffer1[RX_BUFFER_SIZE1];
char rx_buffer0[RX_BUFFER_SIZE0];
char GPS_data[GPS_BUFFER];

char data_bytes[DATA_BYTES0];
char data_0[DATA_BYTES0];

unsigned char adc_data[LAST_ADC_INPUT-FIRST_ADC_INPUT+1];

bit rx_buffer_overflow1;
bit rx_buffer_overflow0;

unsigned int GPS_index;
unsigned int Timer_0;
unsigned int status;
unsigned int c_counter;
unsigned int rx_wr_index1,rx_rd_index1,rx_counter1;
unsigned int rx_wr_index0, rx_rd_index0, rx_counter0, counter;
unsigned int tx_rd_index0,tx_counter0,tx_wr_index0;

int delta_u;                                      // Deklaracia premennej rozdielu napatia medzi akumulatorom a solarnym panelom
unsigned char obmedzenie=0;                       // Deklaracia premennej obmedzenie
unsigned char i;                                  // Deklaracia premennej i
unsigned char status_1=0;                         // Deklaracia premennej status nabijania
bit panel;

//************************************************************* ADC ******************************************************************

// ADC interrupt service routine
// with auto input scanning
interrupt [ADC_INT] void adc_isr(void)
{
        register static unsigned char input_index=0;
        // Read the 8 most significant bits
        // of the AD conversion result
        adc_data[input_index]=ADCH;
        // Select next ADC input
        if (++input_index > (LAST_ADC_INPUT-FIRST_ADC_INPUT))
           input_index=0;
        ADMUX=(FIRST_ADC_INPUT|ADC_VREF_TYPE)+input_index;
        // Start the AD conversion
        ADCSRA|=0x40;
}


//**************************************************** RX INTERRUPT USART0 ***********************************************************

// USART0 Receiver interrupt service routine
interrupt [USART0_RXC] void usart0_rx_isr(void)
        {
        char status,data;
        status=UCSR0A;
        data=UDR0;
        if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
                {
                rx_buffer0[rx_wr_index0]=data;
                if (++rx_wr_index0 == RX_BUFFER_SIZE0)
                        rx_wr_index0=0;
                if (++rx_counter0 == RX_BUFFER_SIZE0)
                        {
                        rx_counter0=0;
                        rx_buffer_overflow0=1;
                        };
                };
        }

//**************************************************** TX INTERRUPT USART0 ************************************************************

// USART0 Transmitter interrupt service routine
interrupt [USART0_TXC] void usart0_tx_isr(void)
{
if (tx_counter0)
   {
   --tx_counter0;
   UDR0=tx_buffer0[tx_rd_index0];
   if (++tx_rd_index0 == TX_BUFFER_SIZE0)
        tx_rd_index0=0;
   };
}

//***************************************************** RD_USART0 *****************************************************************

void RD_USART0(void)
         {
         while(rx_counter0 != 0)
                  {
                  #asm("cli")
                  data_0[counter] = rx_buffer0[rx_rd_index0];

                  if(data_0[counter - 7] == '$' && data_0[counter - 6] == 'A' && data_0[counter - 5] == '7')
                        {
                        if(data_0[counter] == 10/*<LF>*/)
                                {
                                data_bytes[2] = data_0[counter - 4];
                                data_bytes[1] = data_0[counter - 3];
                                data_bytes[0] = data_0[counter - 2];
                                counter = 0;
                                goto here1;
                                }
                        }
                   counter++;
                   here1:
                   if(++rx_rd_index0 == RX_BUFFER_SIZE0)
                        rx_rd_index0 =0;
                   --rx_counter0;
                  #asm("sei")
                  }
         }

char RD_DATA_BUFFER(int znak)
        {
        return data_bytes[znak];
        }


//************************************************** RX INTERRUPT USART1 *************************************************************
// USART1 Receiver interrupt service routine
interrupt [USART1_RXC] void usart1_rx_isr(void)
{
char status,data;
status = UCSR1A;
data = UDR1;

if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN)) == 0)
   {
   rx_buffer1[rx_wr_index1] = data;

   if(++rx_wr_index1 == RX_BUFFER_SIZE1)
          rx_wr_index1=0;

   if(++rx_counter1 == RX_BUFFER_SIZE1)
        {
        rx_counter1=0;
        rx_buffer_overflow1=1;
        };

   };
}
//*********************************************************************************************************************************
void WR_USART0(char data_for_send)
{
         while (tx_counter0 == TX_BUFFER_SIZE0);
         #asm("cli")
         if (tx_counter0 || ((UCSR0A & DATA_REGISTER_EMPTY)==0))
                  {
                  tx_buffer0[tx_wr_index0] = data_for_send;
                  if (++tx_wr_index0 == TX_BUFFER_SIZE0)
                          tx_wr_index0=0;
                  ++tx_counter0;
                  }
         else
                  UDR0=data_for_send;
         #asm("sei")
}

void RD_USART1(void)
        {
        while(rx_counter1 != 0)
                {
                GPS_data[GPS_index] = rx_buffer1[rx_rd_index1];

                #asm("cli")
                if(GPS_data[GPS_index] == 10)
                        {
                        for(c_counter = 0;c_counter <= GPS_index; c_counter++)
                                {
                                WR_USART0(GPS_data[c_counter]);
                                }
                        GPS_index = 0;
                        goto here;
                        };

                GPS_index++;
                here:
                if(++rx_rd_index1 == RX_BUFFER_SIZE1)
                        rx_rd_index1 = 0;

                --rx_counter1;
                #asm("sei")
                };
        }

//**************************************************** DEVICES ****************************************************************
void SERVO1( int servo1 )                       //Direction servo
        {
        OCR3CH = (servo1 >> 8) & 0xFF;
        OCR3CL = servo1 & 0xFF;
        }

void SERVO3( int servo3 )                       //Camera servo
        {
        OCR3AH = (servo3 >> 8) & 0xFF;
        OCR3AL = servo3 & 0xFF;
        }

void SERVO2( int servo2 )
        {
        OCR3BH = (servo2 >> 8) & 0xFF;
        OCR3BL = servo2 & 0xFF;
        }

void DC_MOTOR ( int dc_motor )
        {
        OCR1BH = (dc_motor >> 8) & 0xFF;
        OCR1BL = dc_motor & 0xFF;
        }

void BATTERY_STATUS(void)
        {
        if(status == 1)
                {
                WR_USART0('$');
                WR_USART0('M');
                WR_USART0('S');
                WR_USART0('G');
                WR_USART0('1');
                WR_USART0(',');
                WR_USART0(adc_data[0]);
                WR_USART0(13);             //<CR>
                WR_USART0(10);             //<LF>

                status = 0;
                }
        }
//**************************************************** TIMER_0 ***************************************************************
//Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
TCNT0=0x01;
Timer_0++;
if(Timer_0 == 28)
        {
        status = 1;
        Timer_0 = 0;
        }
}
/*********************************************************************************************************************************
********************************************* STANDARDNE A UKONCOVACIE NABIJANIE ************************************************/
int STANDARDNE_NABIJANIE()
{
while(2)                                                // Cyklus bez podmienky
        {
        panel=1;                                        // Premenna panel=1, koli vypadkom slnecneho ziarenia a poklesu napatia
        GENERATOR=0x1C;                                 // Zapne generator pulzov na frekvenciu 28.8 KHz
        for(i=0;i<9;i++)                                // Cyklus pre rychle nabijanie a meranie
                {
                delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;  // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
                if(delta_u>=15 && panel==1)              // Ak je napatie panelu vacsie ako 15V a nevypadlo ziarenie pocas cyklu, tak odpoji zdroj
                ZDROJ=1;                                // Zapne port pre odpojenie zdroja
                NABIJANIE=0;                            // Zapne port pre nabijanie
                delay_ms(50);                           // Nabija a caka 50ms
                delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;  // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
                if(delta_u<15)                          // Ak vypadne ziarenie, tak cely cyklus je nahradeny zdrojom
                        {
                        panel=0;                        // panel=0, koli tomu aby sa v tomto cykle uz nenabijalo pomocou Solarneho panelu
                        ZDROJ=0;                        // Pripoji zdroj
                        }
                delay_ms(50);                           // Nabija a caka 50 ms koli stabilzacii zdroja
                if(NAPATIE_ZDROJA<165)                  // Ak je napatie zdroja mensie ako 15V, tak odpoji nabijanie (1)
                break;                                  // Prerusi cyklus (nabijanie) (1)
                }
        if(NAPATIE_ZDROJA<165)                          // Ak je napatie zdroja mensie ako 15V, tak odpoji nabijanie (2)
                {
                GENERATOR=0x00;                         // Odpoji generator pulzov
                ZDROJ=0;                                // Pripoji zdroj
                break;                                  // Prerusi cyklus (nabijanie) (2)
                }
        if(NABIJACI_PRUD>=125)                          // Ak je nabijaci prud mensi ako 50mA, tak odpoji nabijanie
                {
                GENERATOR=0x00;                         // Odpoji generator pulzov
                status_1=1;                               // staus=1, ked je plna kapacita
                break;                                  // Prerusi cyklus (nabijanie)
                }

        /*if(TEPLOTA_AKUMULATORA>=179)                    // Ak je teplota akumulatora vyssia ako 50C, tak uplne odpoji nabijanie
                {
                GENERATOR=0x00;                         // Odpoji generator pulzov
                status_1=2;                               // status=2, ked je prekroceny limit teploty
                break;                                  // Prerusi cyklus (nabijanie)
                }*/
        delay_ms(100);                                  // Caka 100ms
        obmedzenie++;
        status_1 = 3;                                   // Pripocita 1 koli obmedzeniu zapornych impulzov na akumulatore
        if(NAPATIE_AKU<165 || obmedzenie>=10)            /* Ak je napatie na akumulatore mensie ako 13.5V, alebo obmedzovaci pocet cyklov
                                                        vacsi alebo rovny 10, tak sa spusti zaporny impulz */
                {
                NABIJANIE=1;                            // Vypne port pre nabijanie
                delay_ms(1);                            // Caka 1ms na stabilizaciu
                ZAPORNE_NAPATIE=1;                      // Zapne port pre zaporne napatie
                delay_us(5);                            // Caka 5us
                ZAPORNE_NAPATIE=0;                      // Vypne port pre zaporne napatie
                delay_ms(1);                            // Caka 1ms na stabilizaciu
                obmedzenie=0;                           // Vynuluje premennu obmedzenie
                }
        }
        return status;
}
/*********************************************************************************************************************************
*************************************************** UDRZIAVACIE NABIJANIE *******************************************************/
int UDRZIAVACIE_NABIJANIE()
{
while((status_1 == 1) && (NAPATIE_ZDROJA>=181 || delta_u>=15))  // Ak akumulator ma plnu kapacitu a je pripojeny zdroj, tak prechadza do rezimu udrzovacieho nabijania
        {
        NABIJANIE=0;                                    // Zapne port pre nabijanie
        delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;       // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
        if(delta_u >= 15)                                 // Ak je delta_u vacsie ako 14, tak odpoji zdroj
                ZDROJ=1;                                // Odpoji zdroj
        else                                            // Pokial predchadzajuca podmienka neplati, tak zdroj ostane pripojeny
                ZDROJ=0;                                // Pripoji zdroj
        delay_ms(50);                                   // Caka 50ms
        }
return delta_u;
}
/*********************************************************************************************************************************
**************************************************** ZAKAZANE NABIJANIE *********************************************************/
int ZAKAZANE_NABIJANIE()
{
while((status_1==2) && ((NAPATIE_ZDROJA>=165) || (delta_u>=15)))  // Ak akumulator prekrocil teplotu 45C, tak nabijanie sa automaticky odpaja
        {
        NABIJANIE=1;                                    // Vypne port pre nabijanie
        delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU;       // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
        if(delta_u >= 15)                                 // Ak je delta_u vacsie ako 14, tak odpoji zdroj
                ZDROJ=1;                                // Odpoji zdroj
        else                                            // Pokial predchadzajuca podmienka neplati, tak zdroj ostane pripojeny
                ZDROJ=0;                                // Pripoji zdroj
        delay_ms(50);                                   // Caka 50ms
        }
return delta_u;
}
/*********************************************************************************************************************************
***************************************************** POMOCNE NABIJANIE *********************************************************/
void POMOCNE_NABIJANIE()
{
if(delta_u>=15 && NAPATIE_ZDROJA<184)
//if(NAPATIE_ZDROJA>184)          // Ak je delta_u vacsie ako 14 a nieje pripojeny zdroj, tak pripoji panel ako pomocny zdroj napajania
NABIJANIE=0;                                    // Zapne port pre nabijanie (pre podporu napajania)
else                                            // Pokial predchadzajuca podmienka neplati, tak podpora napajania zostane vypnuta
NABIJANIE=1;                                    // Vypne port pre nabijanie
}

//****************************************************************************************************************************
//***************************************************** MAIN *****************************************************************

void main(void)
{

int servo_start_position = 280;
//int dc_motor_start_position = 0;
int korekcia_1 = 146;
int a;
char data[DATA_BYTES0];

//****************************************** PORT A
// Input/Output Ports initialization
// Port A initialization
// Func7=In Func6=Out Func5=In Func4=In Func3=Out Func2=Out Func1=In Func0=In
PORTA=0x00;
DDRA=0x4C;
//****************************************** PORT B
// Port B initialization
// DDRB.0 = 1;  PORTB.0 = 1; SERVO1 - power supply transistor - (normally ON)
// DDRB.6 = PWM OC3A   PORTE.3 = 0
PORTB=0x01;
DDRB=0x51;
//****************************************** PORT C
//DDRC.7 = 1; PORTC.7 = 1; CAMERA ON/OFF (normally ON)
//DDRC.2, DDRC.4 = 0; OPTICALS SENSORS
PORTC=0x80;
DDRC=0x80;
//****************************************** PORT D
// Port D initialization
// DDRD.5 = 1; PORTD.5 = 0; DC_MOTOR_Direction 1/1 (normally OFF)
// DDRD.6 = 1; PORTD.6 = 0; DC_MOTOR_Direction 1/2 (normally OFF)
PORTD=0x02;
DDRD=0x60;
//****************************************** PORT E
// Port E initialization
// DDRE.3 = PWM OC3A   PORTE.3 = 0; SERVO#2
// DDRE.4 = PWM OC3B   PORTE.4 = 0; SERVO#1
// DDRE.5 = PWM OC3C   PORTE.5 = 0; SERVO#3
// DDRE.6 = 1;  PORTB.6 = 1; SERVO2 - power supply transistor - (normally ON)
// DDRE.7 = 1;  PORTB.7 = 1; SERVO3 - power supply transistor - (normally ON)
PORTE=0xC0;
DDRE=0xF8;
//****************************************** PORT F
// Port F initialization
PORTF=0x00;
DDRF=0x00;
//****************************************** PORT G
// Port G initialization
PORTG=0x00;
DDRG=0x00;
//****************************************** TIMER 0
// Timer/Counter 0 initialization
// Clock source: 7200Hz System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=FFh
// OC0 output: Disconnected
ASSR=0x00;
TCCR0=0x07;
TCNT0=0x01;
//TCCR0=0x00;
//TCNT0=0x00;
OCR0=0x00;
//****************************************** TIMER 1
// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 7372,800 kHz
// Mode: Ph. & fr. cor. PWM top=ICR1
// OC1A output: Discon.
// OC1B output: Non-Inv.
// OC1C output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
// Compare C Match Interrupt: Off
TCCR1A=0x20;
TCCR1B=0x12;
TCNT1H=0x00;
TCNT1L=0x00;

ICR1H =(DC_MOTOR_PWM >> 8) & 0xFF;
ICR1L = DC_MOTOR_PWM & 0xFF;

DC_MOTOR(0);  //DC motor null

//***************************************** TIMER 2
// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;
//***************************************** TIMER 3
// Timer/Counter 3 initialization
// Clock source: System Clock
// Clock value: 7372,800 kHz
// Mode: Ph. & fr. cor. PWM top=ICR3
// Noise Canceler: Off
// Input Capture on Falling Edge
// OC3A output: Discon.
// OC3B output: Non-Inv.
// OC3C output: Discon.
// Timer 3 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
// Compare C Match Interrupt: Off
TCCR3A=0xA8;
TCCR3B=0x12;
TCNT3H=0x00;
TCNT3L=0x00;

ICR3H =(SERVOS_PWM >> 8) & 0xFF;
ICR3L = SERVOS_PWM & 0xFF;

SERVO1(servo_start_position);
SERVO2(servo_start_position);
SERVO3(servo_start_position);
//**************************************************

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
// INT3: Off
// INT4: Off
// INT5: Off
// INT6: Off
// INT7: Off
EICRA=0x00;
EICRB=0x00;
EIMSK=0x00;
//**************************************************
// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x01;
ETIMSK=0x00;
//**************************************************
// USART0 initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART0 Receiver: On
// USART0 Transmitter: On
// USART0 Mode: Asynchronous
// USART0 Baud rate: 19200
UCSR0A=0x00;
UCSR0B=0xD8;
UCSR0C=0x06;
UBRR0H=0x00;
UBRR0L=0x17;
//**************************************************
// USART1 initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART1 Receiver: On
// USART1 Transmitter: On
// USART1 Mode: Asynchronous
// USART1 Baud rate: 4800
UCSR1A=0x00;
UCSR1B=0xD8;
UCSR1C=0x06;
UBRR1H=0x00;
UBRR1L=0x5F;
//**************************************************
// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 900,600 kHz
// ADC Voltage Reference: AREF pin
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=FIRST_ADC_INPUT|ADC_VREF_TYPE;
//ADMUX=FIRST_ADC_INPUT | (ADC_VREF_TYPE & 0xff);
//ADCSRA=0xCD;
ADCSRA=0xCF;

//***************************************************
// Global enable interrupts
#asm("sei")

while (1)
      {
       RD_USART1();             //Read GPS data from USART1
       BATTERY_STATUS();        //Send msg "battery status"
       RD_USART0();             //Read incoming msg
       data[2] = RD_DATA_BUFFER(2);
       data[1] = RD_DATA_BUFFER(1);
       data[0] = RD_DATA_BUFFER(0);
       switch(data[2])
                {
                case 'M':  ///////////////////////////// MOTION //////////////////////////////
                if((PINC.2 | PINC.4)==0)
                        {
                        FOREWARD = 1;
                        BACKWARD = 1;
                        DC_MOTOR (63);
                        }
                else if(PINC.2==0)
                        {
                        FOREWARD = 1;
                        BACKWARD = 0;
                        DC_MOTOR(25000);
                        }
                else if(PINC.4==0)
                        {
                        FOREWARD = 0;
                        BACKWARD = 1;
                        DC_MOTOR(25000);
                        }
                else if(data[1] == '!')                  // FOREWARD
                        {
                        FOREWARD = 0;
                        BACKWARD = 1;
                        a = (int)data[0];
                        DC_MOTOR ( korekcia_1 * a);
                        }

                else if(data[1] == '%')              // BACKWARD
                        {
                        FOREWARD = 1;
                        BACKWARD = 0;
                        a = (int)data[0];
                        DC_MOTOR ( korekcia_1 * a);
                        }

                else if(data[1] == ')')              // STOP
                        {
                        FOREWARD = 1;
                        BACKWARD = 1;
                        DC_MOTOR (63);
                        }
                break;

             case 'D':   ////////////////////////// DIRECTION /////////////////////////////

                if(data[1] == '1')
                        {
                        DIRECTION_SERVO = 1;                 //Direction Servo#1 enabled
                        }
                else if(data[1] == '0')
                        {
                        DIRECTION_SERVO = 0;                 //Direction Servo#1 disabled
                        }
                a = (int)data[0];
                SERVO1(servo_start_position + 5*a);
                a = 0;

                break;

             case 'G':   /////////////////////////////GPS /////////////////////////////////

                if(data[1] == '1')
                        {
                        GPS = 1;                 //enabled
                        }
                else if(data[1] == '0')
                        {
                        GPS = 0;                 //disabled
                        }
                break;

             case 'C':   /////////////////////////// CAMERA ///////////////////////////////

                if(data[1] == '1')                   //camera servo#2
                        {
                        a = (int)data[0];
                        SERVO2(servo_start_position + 5*a);
                        a = 0;
                        }
                else if(data[1] == '2')              //camera servo#3
                        {
                        a = (int)data[0];
                        SERVO3(servo_start_position + 5*a);
                        a = 0;
                        }
                else if(data[1] == '3')
                        {
                        if(data[0] == '0')
                                H_V_CAM_SERVO = 0;     //servo#2,3 disabled
                        else if(data[0] == '1')
                                H_V_CAM_SERVO = 1;     //servo#2,3 enabled
                        }
                else if(data[1] == '5')
                        {
                        if(data[0] == '0')
                                CAMERA = 0;     //camera disabled
                        else if(data[0] == '1')
                                CAMERA = 1;     //camera enabled
                        }
                break;

             default:
                break;
             }
             //*************************************************charging
             while(NAPATIE_ZDROJA>=184)                // Ak je napatie na zdroji vacsie ako 15V, tak sa zacne cyklus standardneho nabuijania

              {
              TCCR0=0x00;
              TCNT0=0x00;
              H_V_CAM_SERVO = 0;
              CAMERA = 0;
              GPS = 0;
              DIRECTION_SERVO = 0;
              DC_MOTOR (63);
              STANDARDNE_NABIJANIE();                   // Vola funkciu pre standardne nabijanie
              }

              delta_u=(NAPATIE_PANELU*1.4)-NAPATIE_AKU; // Zapise zmenu napatia medzi akumulatorom a napatim panelu do delta_u
              UDRZIAVACIE_NABIJANIE();                  // Vola funkciu pre udrziavacie nabijanie
              ZAKAZANE_NABIJANIE();                     // Vola funkciu pre zakazane nabijanie
              if (status_1 !=0)
                {
                status_1=0;                               // Ak uplne vyjde nabijanie zo vsetkych cyklov, tak status=0
                H_V_CAM_SERVO = 1;
                CAMERA = 1;
                GPS = 1;
                DIRECTION_SERVO = 1;
                TCCR0=0x07;   //enable interrupt 0
                TCNT0=0x01;
                }
              POMOCNE_NABIJANIE();

      };
}
